<?php
class MailTrap {
    //Change those setting using your mailtrap account
    const SMTP_HOST = "smtp.mailtrap.io";
    const SMTP_PORT = "465";
    const SMTP_USER = "eb6c59a7dafbef";
    const SMTP_PASSWORD = "d0d453d08bfdff";

}