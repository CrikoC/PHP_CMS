<?php
//Database constants
defined('DB_SERVER') ? NULL : define('DB_SERVER', 'localhost');
defined('DB_USER') ? NULL : define('DB_USER', 'root');
defined('DB_PASS') ? NULL : define('DB_PASS', '');
defined('DB_NAME') ? NULL : define('DB_NAME', 'cms');
