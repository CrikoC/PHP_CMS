</div>
<!-- /#wrapper -->

<!-- jQuery -->
<script src="includes/js/jquery.js"></script>

<script src="includes/js/scripts.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="includes/js/bootstrap.min.js"></script>
<script src="includes/js/bootstrap-validator.js"></script>


</body>

</html>