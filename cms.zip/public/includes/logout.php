<?php require_once("../../includes/initialize.php"); ?>
<?php
$session->logout();
redirect_to("/cms/public/index");